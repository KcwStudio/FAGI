---
name: fagi-update
description: |
  FAGI 更新器。用户说「更新 FAGI」「升级 FAGI」「把 FAGI 更新到最新版」「检查 FAGI 更新」或输入 /fagi-update 时使用。只同步 KcwStudio/FAGI 仓库，不更新用户安装的其他 Skill，不修改用户的个人规则库和存档。
  Update FAGI when the user asks to update, upgrade, or check updates for FAGI.
---

# fagi-update：更新 FAGI

用户已经明确要求更新 FAGI。直接执行更新，不再做第二次文字确认；宿主若要求 Shell 权限，由用户在宿主的权限窗口中决定。

## 更新范围

- 只从目标仓库 `KcwStudio/FAGI`（https://github.com/KcwStudio/FAGI）更新。
- 保留用户在各 skill 的 `data/` 目录中的个人规则库、审查历史、踩坑案例、词库文件。
- 保留用户项目的 `.workbuddy/skills/` 符号链接配置。
- 不更新用户安装的其他 Skill。
- 不创建后台任务、定时任务或 Agent Hook。

## 受保护的个人数据（更新时不覆盖）

以下路径是用户的个人资产，更新时必须保留，不覆盖、不删除：

| skill 目录 | 受保护路径 | 内容 |
|---|---|---|
| `fagi-publish-precheck/` | `data/profile.md` | 用户账号画像 |
| `fagi-publish-precheck/` | `data/my-rules.md` | 个人黑名单/白名单/语义规则 |
| `fagi-publish-precheck/` | `data/expressions.md` | 安全表达库（实测改写对） |
| `fagi-publish-precheck/` | `data/wordlists/` | 个人大词表 |
| `fagi-publish-precheck/` | `data/history/` | 审查历史报告 |
| `fagi-publish-precheck/` | `data/cases/` | 被罚案例存档 |
| `fagi-xhs-dual-account-strategist/` | `data/` | 行业映射等用户配置 |
| 所有 skill | `data/` 目录下除 `README.md` 和 `templates/` 外的所有文件 | 用户运行时产生的数据 |

## 执行步骤

1. **识别 FAGI 安装位置**：全局更新时，Codex 使用 `~/.codex/skills/`，WorkBuddy 使用 `~/.workbuddy/skills/`；若用户明确要求更新某个 FAGI 项目，按该项目 `SOURCE_OF_TRUTH.md` 定位 `skills/` 真源。只处理 `fagi` 主入口和 `fagi-*` 子 skill。遇到指向项目真源的符号链接时，在真源更新内容，保留链接本身。

2. **备份用户个人数据**：更新前先把所有 skill 的 `data/` 目录（除 `README.md` 和 `templates/`）备份到临时目录 `/tmp/fagi_update_backup_<timestamp>/`。

3. **从 GitHub 拉取最新版本**：

   ```bash
   git clone --depth 1 https://github.com/KcwStudio/FAGI.git /tmp/fagi_update_<timestamp>/
   ```

   如果仓库里只有 `FAGI.zip`，解压后取 `fagi/` 目录下的内容；如果已经是展开的 skill 目录结构，直接使用。

4. **逐个更新 skill**：对每个 FAGI 相关 skill（`fagi`、`fagi-xhs-competitor-analyzer`、`fagi-xhs-keyword-planner`、`fagi-xhs-dual-account-strategist`、`fagi-xhs-title-optimizer`、`fagi-xhs-note-writer`、`fagi-xhs-compliance-check`、`fagi-publish-precheck`、`fagi-xhs-data-review`、`fagi-update`）：

   - 将发布包 `fagi/` 本身作为主入口，直属的 `fagi-*` skill 各自安装到全局目录同名位置；不要把子 skill 再嵌套复制到全局 `fagi/` 中。
   - 同步每个 skill 随包提供的全部普通文件（包括 `agents/`、`tests/`、脚本与引用资源），不只复制 `SKILL.md`；不删除安装位置已有的额外文件。
   - 新增的 `fagi-xhs-competitor-analyzer` 不存在时创建，已单独安装时原位更新；保留任何现有符号链接，在链接真源写入。
   - **不覆盖** `data/` 目录（保留用户个人数据）
   - 如果 GitHub 版本新增了 `data/` 下的模板文件（如 `templates/` 内的文件），补充进来但不覆盖已有同名文件

5. **恢复用户个人数据**：从临时备份恢复用户 `data/` 目录（覆盖更新可能误带入的模板）。

6. **清理临时目录**：更新完成后删除 `/tmp/fagi_update_<timestamp>/` 和 `/tmp/fagi_update_backup_<timestamp>/`。

7. **验证安装**：检查全部 10 个 skill 的 `SKILL.md` 存在且 frontmatter `name` 与目录名一致；逐文件核对发布版本（受保护的 `data/` 除外）；核对个人数据哈希和符号链接目标未变。确认主入口的专家映射、`package.json` 和本更新器均包含 `fagi-xhs-competitor-analyzer`。

## 回复格式

成功：

> FAGI 已更新完成。当前对话如果还没有读取到新能力，新建一次对话后即可使用。
>
> 更新了以下 skill：
> - fagi（主入口）
> - fagi-xhs-competitor-analyzer（对标分析师）
> - fagi-xhs-keyword-planner（关键词研究员）
> - fagi-xhs-dual-account-strategist（双账号策略师）
> - fagi-xhs-title-optimizer（标题优化师）
> - fagi-xhs-note-writer（笔记作家）
> - fagi-xhs-compliance-check（合规检测官）
> - fagi-publish-precheck（发布前审查官）
> - fagi-xhs-data-review（数据复盘师）
> - fagi-update（更新器）
>
> 你的个人规则库（data/ 目录）已保留，无需重新配置。

失败：

> FAGI 没有更新完成：{简短原因}。处理完 {权限或网络问题} 后，再说一次「更新 FAGI」。

## 边界

- 用户只问版本、更新内容或是否需要更新时，先回答问题，不执行命令。
- 用户明确要求检查更新且希望实际同步时，按本 Skill 更新。
- 不更新非 FAGI 的其他 Skill（如 dbskill、khazix-skills 等）。
- 不修改用户的 `.workbuddy/skills/` 符号链接配置。
- 不修改用户项目的 `AGENTS.md`、`README.md`、`SOURCE_OF_TRUTH.md` 等项目级文件。
- 如果 GitHub 仓库结构变化导致 skill 目录名调整，更新前先告知用户变化，获得确认后再执行。
